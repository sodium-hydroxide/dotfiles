## Homebrew Configuration

The applications are managed in a declarative manner using a `Brewfile` and the
script `main_brew.sh` to update homebrew, install packages and programs, and
update existing packages.

