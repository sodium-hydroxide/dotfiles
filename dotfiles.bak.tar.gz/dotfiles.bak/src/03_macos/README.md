## macOS Configuration

These are global and user settings (along with default file settings) that are
applied. The main functions will check if a setting has been applied already
to improve speed.

